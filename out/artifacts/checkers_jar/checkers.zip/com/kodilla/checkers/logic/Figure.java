package com.kodilla.checkers.logic;

public interface Figure {
    String getColour();
}
