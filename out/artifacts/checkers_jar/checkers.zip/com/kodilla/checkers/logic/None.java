package com.kodilla.checkers.logic;

public class None implements Figure {
    @Override
    public String getColour() {
        return null;
    }
}
